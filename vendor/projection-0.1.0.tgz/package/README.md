# projection

ChallengeRelay SDK，提供 protocol 与 workflow runtime 入口。

## 入口

- `@challenge-relay/projection/protocol`
- `@challenge-relay/projection/workflow`

协议说明见 [docs/protocol.md](./docs/protocol.md)。

## Launch Config

workflow app 通过 `--config <json-path>` 读取启动配置。公共配置结构由
`@challenge-relay/projection/workflow` 负责解析，各 workflow 只需要补充自己的
`data` 载荷语义。

```json
{
  "channel": "50c3300f-83eb-476b-ba8b-cedc93cfbd0b",
  "config": {
    "workflow": {
      "id": "wf_demo_01",
      "kind": "demo"
    },
    "platform": {
      "url": "http://127.0.0.1:3000"
    },
    "browser": {
      "endpoint": "http://localhost:9222"
    },
    "target": {
      "url": "https://accounts.hcaptcha.com/demo",
      "pageMatch": "accounts.hcaptcha.com/demo"
    },
    "stream": {
      "intervalMs": 66,
      "jpegQuality": 70,
      "tileSize": 10,
      "keyframeIntervalMs": 2000
    }
  },
  "data": {}
}
```

### 命名约定

ChallengeRelay 自有字段统一使用 `camelCase`，例如 `intervalMs`、
`jpegQuality`、`keyframeIntervalMs`。第三方透传配置保留上游字段风格，
例如 `config.browser.adspower.profile_id` 和 `proxy_soft`。

### 公共字段

- `channel`：启动保护字段，目前必须使用示例值。
- `config.workflow.id`：稳定逻辑身份，用于 platform 寻址。
- `config.workflow.kind`：workflow 类型。
- `config.workflow.nodeId`：可选，单次进程实例身份；不填时自动生成。
- `config.platform.url`：platform HTTP base URL。
- `config.browser.endpoint`：浏览器连接入口，支持 Chromium DevTools 地址和 Playwright endpoint。
- `config.browser.engine`：可选，浏览器运行时类型。
- `config.browser.provider`：可选，浏览器入口提供方标记。
- `config.browser.adspower`：可选，AdsPower Local API 配置；字段按 AdsPower API 风格透传，详见 [`@challenge-relay/adspower`](../adspower/README.md)。
- `config.target.url`：workflow 启动后要打开的目标页面。
- `config.target.pageMatch`：从已连接浏览器中定位目标页面用的 URL 片段。
- `config.stream.intervalMs`：frame 投射最小间隔，常用值 `66` 到 `150`。
- `config.stream.jpegQuality`：CDP screencast JPEG 质量，常用值 `70`。
- `config.stream.tileSize`：差分 tile 尺寸，常用值 `10`。
- `config.stream.keyframeIntervalMs`：强制关键帧间隔，常用值 `2000`。
- `data`：workflow 自有业务参数；具体字段由对应 workflow README 说明。

`stream` 参数只控制 ChallengeRelay frame 协议的投射节奏和差分编码。当前 CDP
screencast 会先从浏览器取得完整 viewport JPEG，再由 SDK 在 workflow 侧裁剪活跃区域；
如果 CDP 连接经过互联网，最佳长期优化是让 workflow 尽量靠近浏览器/CDP 运行，单纯降低
`intervalMs` 往往会增加排队和端到端延迟。

旧版顶层字段已删除，不再兼容 `workflowId`、`platformWsUrl`、`cdpUrl`、
`streamFrameIntervalMs`、`projectionTransport`、`mediaBaseUrl`、`mediaFrameRate`
等配置。新配置必须放入 `workflow`、`platform`、`browser`、`target`、`stream`
这些结构化对象。

## 命令

```bash
npm --workspace @challenge-relay/projection run build
npm --workspace @challenge-relay/projection run typecheck
npm --workspace @challenge-relay/projection run pack:sdk
```

`dist/` 和 `release/` 都是生成产物，不提交。
